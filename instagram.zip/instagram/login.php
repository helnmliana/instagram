<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous"></a>
    <link rel="icon" href="nature beauty.png" href="style.css">
    <title>Nature Beauty</title>
    <style>
       body {
        background-image: url('gunung6.jpg');
        backdrop-filter: blur(10px);
        background-position: center;
        background-size: 1390px
        }
    </style>
</head>
<body>
    <div class="container">
      <div class="row justify-content-center mt-5">
        <div class="col-md-4">
          <div class="card" style="margin-top:100px">
            <center>
            <img src="nature beauty.png" height="100" width="100">
            </center>
            <div class="card-header bg-transparent mb-0"><h5 class="text-center"><span class="font-weight-bold text-dark">ℕ𝕒𝕥𝕦𝕣𝕖 𝔹𝕖𝕒𝕦𝕥𝕪</span></h5></div>
            <div class="card-body">
              <form action="proses_login.php" method="post">
                <div class="form-group">
                  <input type="text" name="username" class="form-control" placeholder="Username"><br>
                </div>
                <div class="form-group">
                  <input type="password" name="password" class="form-control" placeholder="Password"><br>
                </div>
                <div class="form-group">
                  <center>
                  <input type="submit" name="" value="Login" class="btn btn-primary btn-block">
                  </center>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>