<?php
include "koneksi.php";
require "functions.php";

if (isset($_POST['update'])) {
    $no = $_POST['no'];
    $caption = $_POST['caption'];
    $lokasi = $_POST['lokasi'];
    $foto_lama = $_POST['foto_lama'];
    $foto_baru = $_FILES['gambar']['name'];

    // jika gambarnya sama, pakai gambar yang lama
    if( $_FILES['gambar']['error'] === 4 ) {
		$gambar = $foto_lama;
	} else {
        $sql = "SELECT * FROM post WHERE no = '$no' ";
        $query = mysqli_query($koneksi, $sql);
    
        // menghapus gambar lama karena nanti akan diganti yang baru
        while($post = mysqli_fetch_assoc($query)) {
            $gambar = $post['gambar'];
            unlink('images/' . $gambar);
        }

        // lakukan proses upload gambar baru
		$gambar = upload();
	}
    
    $sql2 = "UPDATE post SET gambar = '$gambar', caption = '$caption', lokasi = '$lokasi' WHERE no = '$no' ";
    $query2 = mysqli_query($koneksi, $sql2);

    if ($query2) {
        header("location:index.php?edit=sukses");
    } else {
        header("location:index.php?edit=gagal");
    }
    
}